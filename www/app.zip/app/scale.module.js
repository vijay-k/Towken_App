(function() {
    'use strict';

    angular.module('scale', ['ionic',  'ngCordova','timer',  'ngFileUpload', 'ionic.rating', 'uiGmapgoogle-maps',  'ngResource', 'ngStorage']);
})();